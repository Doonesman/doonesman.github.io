<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Jada Embroidery and Printing</title>
</head>

<body>
<?php include("header.php") ; ?>
<p>Buy some stuff!</p>
</body>
</html>
